CAP = 64
