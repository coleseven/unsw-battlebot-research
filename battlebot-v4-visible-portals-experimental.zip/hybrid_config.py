MODE = 'evaluator'
